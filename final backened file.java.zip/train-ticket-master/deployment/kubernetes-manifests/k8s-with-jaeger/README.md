> TrainTicket with Jaeger

We provide a Tracing System based on [Jaeger](https://www.jaegertracing.io). 

After the deployment, you can visit the Jaeger Webpage at [http://[Node-IP]:32688](http://[Node-IP]:32688) to view traces in the system.

![Jaeger](<https://raw.githubusercontent.com/FudanSELab/train-ticket/master/image/jaeger.png>)

If you'd like to see the source code which uses Jaeger, it's in the [jaeger branch](https://github.com/FudanSELab/train-ticket/tree/jaeger).