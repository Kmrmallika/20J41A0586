package edu.fudan.common.exception;

/**
 * @author fdse
 */
public class TokenException extends BaseException{

    public TokenException(String message) {
        super(message);
    }
}
