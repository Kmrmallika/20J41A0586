

package org.myproject.ms.monitoring;


public interface ItemReporter {
	
	void report(Item span);
}
