package org.myproject.ms.monitoring.instrument.msg;

import org.myproject.ms.monitoring.ItemExtractor;
import org.myproject.ms.monitoring.ItemTextMap;


public interface MSTMExtra extends ItemExtractor<ItemTextMap> {
}
