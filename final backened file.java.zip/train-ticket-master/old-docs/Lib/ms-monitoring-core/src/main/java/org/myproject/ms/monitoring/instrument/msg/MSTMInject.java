package org.myproject.ms.monitoring.instrument.msg;

import org.myproject.ms.monitoring.ItemInjector;
import org.myproject.ms.monitoring.ItemTextMap;


public interface MSTMInject extends ItemInjector<ItemTextMap> {
}
