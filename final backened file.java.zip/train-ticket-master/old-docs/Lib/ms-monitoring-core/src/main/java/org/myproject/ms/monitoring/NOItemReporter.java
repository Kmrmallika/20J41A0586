

package org.myproject.ms.monitoring;


public class NOItemReporter implements ItemReporter {
	@Override
	public void report(Item span) {

	}
}
