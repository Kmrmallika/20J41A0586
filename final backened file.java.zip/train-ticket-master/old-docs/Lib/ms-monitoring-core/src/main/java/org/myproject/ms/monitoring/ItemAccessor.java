

package org.myproject.ms.monitoring;


public interface ItemAccessor {

	
	Item getCurrentSpan();

	
	boolean isTracing();

}
