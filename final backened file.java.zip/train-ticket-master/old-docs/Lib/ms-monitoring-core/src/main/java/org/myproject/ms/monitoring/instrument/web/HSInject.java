package org.myproject.ms.monitoring.instrument.web;

import org.myproject.ms.monitoring.ItemInjector;
import org.myproject.ms.monitoring.ItemTextMap;


public interface HSInject extends ItemInjector<ItemTextMap> {
}
