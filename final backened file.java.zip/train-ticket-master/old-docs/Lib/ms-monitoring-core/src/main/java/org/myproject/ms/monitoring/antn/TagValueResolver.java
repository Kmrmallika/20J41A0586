package org.myproject.ms.monitoring.antn;


public interface TagValueResolver {

	
	String resolve(Object parameter);
	
}
