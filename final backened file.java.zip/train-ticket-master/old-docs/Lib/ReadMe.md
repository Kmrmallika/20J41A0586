# Add additional lib before setup system
To setup system, we need to add an additional lib to mvn.
## Step 1:
Unzip myproject.zip
## Step 2:
Move the myproject directory to your .m2 directory, where the lib of maven saved.
The path just like .m2\repository\myproject
## Step 3:
Then you can setup system.
