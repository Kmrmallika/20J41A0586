package cancel.entity;

import lombok.Data;

/**
 * @author fdse
 */
@Data
public class GetOrderByIdInfo {

    private String orderId;

    public GetOrderByIdInfo() {
        //Default Constructor
    }

}
